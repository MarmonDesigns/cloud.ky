<?php

$info = array();
$info['plugin-name'] = 'milo-core';
$info['plugin-version'] = '1.0.0';