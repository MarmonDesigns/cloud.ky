<?php

$info = array();
$info['plugin-name'] = 'fresh-custom-loop';
$info['plugin-version'] = '1.0.0';